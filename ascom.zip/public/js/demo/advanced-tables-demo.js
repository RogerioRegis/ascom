//DataTables Initialization
$(document).ready(function() {
    $('#example-table').dataTable();
});