<?php $__env->startSection('title'); ?> Clipping <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- begin PAGE TITLE AREA -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="page-title">
                                <h1>Clipping <small>da Internet</small></h1>
                                <ol class="breadcrumb">
                                    <li><i class="fa fa-home"></i><a href="/"> Home </a></li>
                                    <li class="active"> Clipping </li>
                                    <?php echo $__env->make('section.datahora', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </ol>
                            </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <!-- end PAGE TITLE AREA -->

                   <?php echo $__env->make('section.dashclipping', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>