<?php $__env->startSection('title'); ?> Demandas <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- begin PAGE TITLE AREA -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="page-title">
                                <h1>Demandas <small>da Imprensa</small></h1>
                                <ol class="breadcrumb">
                                    <li><i class="fa fa-home"></i><a href="/"> Home </a></li> <li class="active"> Demandas </li>
                                    <?php echo $__env->make('section.datahora', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </ol>
                            </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <!-- end PAGE TITLE AREA -->


<!-- begin ADVANCED TABLES ROW -->
<div class="row">
    <div class="col-lg-12">
        <div class="portlet portlet-default">
            <div class="portlet-heading">
                <div class="portlet-title">
                    <h4>Lista de Demandas</h4>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="portlet-body">
                <div class="table-responsive">
                    <table id="example-table" class="table table-striped table-bordered table-hover table-green">

                        <thead>
                            <tr>
                                <th>VEÍCULO</th>
                                <th>DATA</th>
                                <th>DEAD LINE</th>
                                <th>STATUS</th>
                                <th></th>
                            </tr>
                        </thead>


                        <tbody>

                            <?php $__currentLoopData = $demandas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demanda): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                            <tr class="odd gradeX">
                                <td style="text-transform:uppercase"><a href="<?php echo e(route('demandas.show', $demanda->id)); ?>"><?php echo e($demanda->veiculo); ?></a></td>
                                <td><?php echo e($demanda->data); ?></td>
                                <td><?php echo e($demanda->deadline); ?></td>
                                <td class="center"><button class="btn btn-xs btn-<?php echo e($demanda->status); ?>">Status da Demanda</button></td>
                                <td class="center">
                                    <a href="demandas/<?php echo e($demanda->id); ?>/edit" class="btn btn-default btn-xs"><i class="fa fa-edit"> </i> Editar</a>
                                    <a href="<?php echo e(route('demandas.show', $demanda->id)); ?>" class="btn btn-success btn-xs"><i class="fa fa-eye">  </i> Vizualizar</a>
                                    <a data-toggle="modal" data-target=".bs-example-modal-sm" class="btn btn-danger btn-xs"> <i class="fa fa-trash"></i> Excrluir
                                    <!--<a href="<?php echo e(url('demandas', $demanda->id)); ?>" data-method="DELETE" class="btn btn-danger btn-xs"> <i class="fa fa-trash"></i> Excrluir-->
                                    </a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.portlet-body -->
        </div>
        <!-- /.portlet -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->

<a class="btn btn-green" href="<?php echo e(route('demandas.create')); ?>">Nova Demanda + <span class="fa fa-bullhorn"></span></a>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>