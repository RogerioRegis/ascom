<?php $__env->startSection('title'); ?> Editar Controle <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- begin PAGE TITLE ROW -->
<div class="row">
    <div class="col-lg-12">
        <div class="page-title">
            <h1>Editar Demanda
                <small></small>
            </h1>
            <ol class="breadcrumb">
                <li><i class="fa fa-dashboard"></i>  <a href="/home">Home</a>
                </li>
                <li class="active">Controle de Demandas</li>
            </ol>
        </div>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<!-- end PAGE TITLE ROW -->


<table class="table table-bordered">
    <thead>
        <tr class="active">
            <th class="text-center" colspan="1">CONTROLE DE CONTRATO</th>
        </tr>
    </thead>
</table>

<?php echo $__env->make('section.erro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::model($demandas, ['route' => ['demandas.update', $demandas->id], 'method' => 'PUT']); ?>


<div class="row">
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo Form::label('veiculo', 'VEÍCULO'); ?>

                    <?php echo Form::text('veiculo', null, ['class' => 'form-control', 'style="text-transform:uppercase"', 'autofocus']); ?>

                </div>
          
                <div class="form-group">
                    <?php echo Form::label('data', 'DATA'); ?>

                    <?php echo Form::date('data', null, ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo Form::label('deadline', 'DEADLINE'); ?>

                    <?php echo Form::time('deadline', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <div class="form-group">
                        <label for="status">STATUS</label>
                        <select class="form-control" name="status">
                            <option value="danger" class="text-red"><strong>EM ABERTO</strong></option>
                            <option value="green"><strong>EXECULTADO</strong></option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Campo para o Obseervações -->
    <div class="col-md-6">
        <div class="form-group">
            <?php echo Form::label('obs', 'OBS:'); ?>

            <?php echo Form::textarea('obs', null, ['class' => 'form-control', 'rows' => '5']); ?>

        </div>
    </div>
</div>

<?php echo Form::submit('Salvar', ['class' => 'btn btn-success']); ?>


<a class="btn btn-default" href="/demandas"><i class="fa fa-reply"></i> Cancelar</a>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>